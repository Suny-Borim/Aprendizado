<div align="center">
  <img src="https://logospng.org/download/html-5/logo-html-5-512.png" width="100" >
  <img src="https://logospng.org/download/css-3/logo-css-3-512.png" width="100" >
  <img src="https://logospng.org/download/javascript/logo-javascript-icon-256.png" width="100" >

</div>

# Projeto NuvemGames
### 📌Aviso
```
Se você usa um monitor que tem a resolução de 1920x1080, na página principal o rodapé está meio que fora do lugar 
e nao sei o por que... mas não quebra em nada e tudo esta funcionando normalmente, agradeço a atenção 

```

# NuvemGames
### O site não tem intenção de ganhar nenhum centavo, mas sim com intuito de facilitar na hora de baixar os meus jogos que estão na nuvem.
O site tem como objetivo reunir todos os meus jogos e do meu irmão e deixar amostra em apenas em um lugar, fique à vontade para poder baixar e jogar e seu Vídeo Game | PC 😉



### 🌐 Veja o projeto funcionando no link a baixo:
- <a href="https://rodrigo-santoos.github.io/NuvemGames/" target="_blank" rel="external">Clique Aqui</a>

## ✒️ Desenvolvido

*  <a href="https://github.com/Rodrigo-Santoos" target="_blank" rel="external">Rodrigo Oliveira</a>
