function reviewModeIsReadOnly () {
  return true;
}
